Documentation for plugin install
